package com.example.demo;

public class ResourceRequestNotFoundException extends Exception {
	public ResourceRequestNotFoundException(String msg) {
		super(msg);
	}

}
